package au.edu.unsw.soacourse.loanapprover;

import javax.jws.WebService;

import au.edu.unsw.soacourse.loandefinitions.ObjectFactory;
import au.edu.unsw.soacourse.loandefinitions.ApprovalType;
import au.edu.unsw.soacourse.loandefinitions.LoanInputType;

@WebService(endpointInterface = "au.edu.unsw.soacourse.loanapprover.LoanApprovalPT")
public class LoanApprovalPTImpl implements LoanApprovalPT {

	@Override
	public ApprovalType approve(LoanInputType loanreq) {
		// TODO Auto-generated method stub
		ObjectFactory factory = new ObjectFactory();

		ApprovalType res = factory.createApprovalType();

		if ((loanreq.getAmount().intValue() > 50000)
				&& (loanreq.getName().length() < 3)) {
			res.setAccept("no");
		}
		else
			res.setAccept("yes");
		return res;
	}

}
