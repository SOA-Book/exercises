@javax.xml.bind.annotation.XmlSchema(namespace = "http://soacourse.unsw.edu.au/loandefinitions", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package au.edu.unsw.soacourse.loandefinitions;
