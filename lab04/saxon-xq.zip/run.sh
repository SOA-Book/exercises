java -cp saxon9he.jar net.sf.saxon.Query -q:$1 -o:$2
